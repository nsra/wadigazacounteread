<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>تعديل العداد</h2>
                </div>
                <br>
            </div>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>للأسف!</strong> هناك مشكلة في مدخلاتك.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('counters.update', $counter->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>الرقم التسلسلي:</strong>
                        <input type="number" name="number" value="<?php echo e($counter->number); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>رقم الموقع:</strong>
                        <input type="text" name="position_number" value="<?php echo e($counter->position_number); ?>"
                            class="form-control" placeholder="من موقع WG:00/00/0000 إلى موقع WG:06/99/9999 ">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>رقم الاشتراك:</strong>
                        <input type="number" name="subscription_number" value="<?php echo e($counter->subscription_number); ?>"
                            class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>المشترك/المستفيد:</strong>
                        <input type="text" name="subscriber" value="<?php echo e($counter->subscriber); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>العنوان:</strong>
                        <textarea class="form-control" style="height:100px" name="address"><?php echo e($counter->address); ?></textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>رقم العداد:</strong>
                        <input type="text" name="counter_number" value="<?php echo e($counter->counter_number); ?>"
                            class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>القراءة السابقة:</strong>
                        <input type="number" name="previous_read" value="<?php echo e($counter->previous_read); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>القراءة الحالية:</strong>
                        <input type="number" name="current_read" value="<?php echo e($counter->current_read); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>الاستهلاك الشهري بالكوب:</strong>
                        <input type="number" name="cups_consumption" value="<?php echo e($counter->cups_consumption); ?>"
                            class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>الاستهلاك الشهري بالشيكل:</strong>
                        <input type="number" name="shekels_consumption" value="<?php echo e($counter->shekels_consumption); ?>"
                            class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>حالة العداد:</strong>
                        <input type="text" name="counter_status" value="<?php echo e($counter->counter_status); ?>"
                            class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>ملاحظات:</strong>
                        <textarea class="form-control" style="height:150px" name="notes" placeholder="ملاحظات"><?php echo e($counter->notes); ?></textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
                    <a class="btn btn-danger text-light" data-toggle="modal" id="smallButton" data-target="#smallModal"
                        data-attr="<?php echo e(route('delete', $counter->id)); ?>" title="حذف العداد">
                        حذف العداد <i class="fas fa-trash text-light fa-lg"></i>
                    </a>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">ارسال</button>
                    <a class="btn btn-primary" href="<?php echo e(route('counters.index')); ?>"> رجوع</a>
                </div>
            </div>
            <input type="hidden" name="url" value=<?php echo e(URL::previous()); ?>>

        </form>
    </div>

    <div class="modal fade" id="smallModal" tabindex="-1" role="dialog" aria-labelledby="smallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header p-1 d-flex align-items-left " dir="ltr">
                    <button type="button" class="btn btn-link outline-none text-muted" data-dismiss="modal"  onClick="removeBackdrop()">
                        <i class="text-muted fa fa-lg fa-times-circle"></i>
                    </button>
                </div>
                <div class="modal-body" id="smallBody">
                    <div>
                        <!-- the result to be displayed apply here -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function removeBackdrop(){
            $('.modal-backdrop').remove();
        }
            
        $(document).on('click', '#smallButton', function(event) {
            event.preventDefault();
            let href = $(this).attr('data-attr');
            $.ajax({
                url: href
                , beforeSend: function() {
                    $('#loader').show();
                },
                // return the result
                success: function(result) {
                    $('#smallModal').modal("show");
                    $('#smallBody').html(result).show();
                }
                , complete: function() {
                    $('#loader').hide();
                }
                , error: function(jqXHR, testStatus, error) {
                    console.log(error);
                    alert("Page " + href + " cannot open. Error:" + error);
                    $('#loader').hide();
                }
                , timeout: 8000
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('counters.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\test laravel excel\resources\views/counters/edit.blade.php ENDPATH**/ ?>