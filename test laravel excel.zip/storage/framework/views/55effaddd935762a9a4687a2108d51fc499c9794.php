
<form action="<?php echo e(route('counterthirds.refresh')); ?>" method="get">
    <div class="modal-body">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <h5 class="text-center"><?php echo e(__('هذا الإجراء سيؤدي إلى استبدال القرآت السابقة بالقرآت الحالية، إذا انتهيت من قراءة جميع عدادات الموقع 08 بالفعل يرجى أخذ نسخة اكسل من البيانات')); ?> </h5>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary"  onClick="removeBackdrop()" data-dismiss="modal"><?php echo e(__("إلغاء")); ?></button>
        <button type="submit" class="btn btn-warning"><?php echo e(__('تصفير')); ?></button>
    </div>

</form>


<?php /**PATH D:\test laravel excel\resources\views/counterthirds/refresh.blade.php ENDPATH**/ ?>