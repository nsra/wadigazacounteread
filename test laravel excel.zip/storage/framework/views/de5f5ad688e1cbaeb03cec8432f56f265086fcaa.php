<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>إضافة قراءة جديدة</h2>
                </div>
                <br>
            </div>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>للأسف!</strong> هناك مشكلة في مدخلاتك.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('counters.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>الرقم التسلسلي:</strong>
                        <input type="number" name="number" value="<?php echo e(old('number')); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>رقم الموقع:</strong>
                        <input type="text" name="position_number" value="<?php echo e(old('position_number')); ?>"
                            class="form-control" placeholder="من موقع WG:00/00/0000 إلى موقع WG:06/99/9999 ">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>رقم الاشتراك:</strong>
                        <input type="number" name="subscription_number" value="<?php echo e(old('subscription_number')); ?>"
                            class="form-control" required>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>المشترك/المستفيد:</strong>
                        <input type="text" name="subscriber" value="<?php echo e(old('subscriber')); ?>" class="form-control" required>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>العنوان:</strong>
                        <textarea class="form-control" style="height:100px" name="address"><?php echo e(old('address')); ?></textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>رقم العداد:</strong>
                        <input type="text" name="counter_number" value="<?php echo e(old('counter_number')); ?>"
                            class="form-control" required>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>القراءة السابقة:</strong>
                        <input type="number" name="previous_read" value="<?php echo e(old('previous_read')); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>القراءة الحالية:</strong>
                        <input type="number" name="current_read" value="<?php echo e(old('current_read')); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>الاستهلاك الشهري بالكوب:</strong>
                        <input type="number" name="cups_consumption" value="<?php echo e(old('cups_consumption')); ?>"
                            class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>الاستهلاك الشهري بالشيكل:</strong>
                        <input type="number" name="shekels_consumption" value="<?php echo e(old('shekels_consumption')); ?>"
                            class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>حالة العداد:</strong>
                        <input type="text" name="counter_status" value="<?php echo e(old('counter_status')); ?>"
                            class="form-control">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>ملاحظات:</strong>
                        <textarea class="form-control" style="height:150px" name="notes" placeholder="ملاحظات"><?php echo e(old('notes')); ?></textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">ارسال</button>
                    <a class="btn btn-primary" href="javascript:history.back()"> رجوع</a>
                </div>
            </div>
            <input type="hidden" name="url" value=<?php echo e(URL::previous()); ?>>

        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('counters.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\test laravel excel\resources\views/counters/create.blade.php ENDPATH**/ ?>