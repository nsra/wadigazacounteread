
<form action="<?php echo e(route('counters.destroy', $counter->id)); ?>" method="post">
    <div class="modal-body">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <h5 class="text-center"><?php echo e(__('هل أنت متأكد من حذف عداد')); ?> <?php echo e($counter->subscriber); ?> ؟</h5>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary"  onClick="removeBackdrop()" data-dismiss="modal"><?php echo e(__("إلغاء")); ?></button>
        <button type="submit" class="btn btn-danger"><?php echo e(__('احذف')); ?></button>
    </div>

</form>


<?php /**PATH D:\test laravel excel\resources\views/counters/delete.blade.php ENDPATH**/ ?>